# Activité 4.3 : Consolidation, agrégation de données

J'ai acquis cette compétence lors du développement de la fonctionnalité **ListerDecomptesEdiGeles** du BFF Assuré.

Dans cette fonctionnalité, certaines informations attendues par les applications clientes n'étaient pas directement disponibles dans les données retournées par le BPM. Il a donc été nécessaire de produire de nouvelles données à partir de plusieurs informations existantes.

L'exemple le plus représentatif est la génération du champ :

```text
LibelleDecompteArchive
```

Cette donnée n'est jamais retournée directement par le BPM.

Pour la construire, le BFF applique la règle métier PRS-DEC-007 qui agrège des données provenant de plusieurs services du système d'information.

Les décomptes sont récupérés auprès du module Prestations Santé du BPM tandis que les nomenclatures nécessaires à l'application de la règle métier sont récupérées au travers d'un appel distinct vers le module Nomenclatures de NR2.

Ces différentes données sont ensuite consolidées afin de produire le libellé du décompte attendu par l'application cliente.

Le mécanisme de consolidation peut être représenté ainsi :

```text
Partenaire exécutant
           │
           ├── Spécialité
           ├── Nomenclatures Pharmacie
           ├── Nomenclatures Biologie
           ├── Nomenclatures Dentaire
           ├── Nomenclatures Consultation
           └── Lignes du décompte

                    ↓

         TrouverLibelleDecompte()

                    ↓

        LibelleDecompteArchive
```

La méthode applique la règle PRS-DEC-007 suivante :

1. Vérifier si la spécialité du partenaire appartient à une nomenclature appartenant au groupe Pharmacie, Biologie ou Dentaire.
2. Si une correspondance existe, utiliser le libellé de cette spécialité.
3. Sinon, analyser les actes présents dans les lignes du décompte.
4. Rechercher un acte de consultation.
5. Utiliser le premier acte correspondant trouvé.
6. À défaut, utiliser le premier acte disponible.

Cette logique permet de calculer automatiquement une donnée métier inexistante dans les données source.

Le schéma global de consolidation est le suivant :

```text
BPM
│
└── DecompteEdiGeles
       │
       ├── PartenaireExecutant
       └── LignesDecompteEdi

NR2
│
├── Nomenclatures Spécialité partenaire
│   ├── Groupe Pharmacie
│   ├── Groupe Biologie
│   └── Groupe Dentaire
└── Nomenclatures Code Acte
    └── Libellés contenant "Consultation"

                ↓

          PRS-DEC-007

                ↓

       LibelleDecompteArchive

                ↓

          DTO BFF

                ↓

       Application cliente
```

Ainsi, alors que le BPM ne retourne que des informations techniques liées au partenaire exécutant et aux actes réalisés, le BFF construit une nouvelle donnée métier directement exploitable par le front. Cette donnée est obtenue sans saisie supplémentaire et repose uniquement sur l'agrégation des informations provenant du BPM et de NR2.

Cette approche permet de produire des informations directement exploitables par le front sans lui imposer la connaissance des règles métier ou des structures internes du BPM.

Cette activité m'a permis de mettre en œuvre un mécanisme d'agrégation de données provenant de plusieurs APIs du système d'information. Les informations retournées par le BPM ont été enrichies à l'aide de données récupérées dans NR2 afin de produire une nouvelle information métier, directement exploitable par les applications clientes, sans leur imposer la connaissance des règles de consolidation sous-jacentes.
