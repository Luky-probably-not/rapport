# Methode TrouverLibelle

```csharp
private static string? TrouverLibelleDecompte(this ClientPS.DecompteEdiGelesDto decompte, IEnumerable<string> nomenclatures, IEnumerable<string> consultations)
{
    var partenaire = decompte.PartenaireExecutant;

    if (nomenclatures.Contains(partenaire?.Specialite.Code))
    {
        return partenaire!.Specialite.Libelle;
    }

    var lignes = decompte.LignesDecompteEdi;
    var lignesTries = lignes.Where(d => d.Acte != null).OrderBy(d => d.IdentifiantLigneDecompteEdi).ToList();
    if (!lignesTries.Any())
    {
        return null;
    }

    var consultation = lignesTries.FirstOrDefault(l => consultations.Contains(l.Acte?.Code));
    return consultation != null
        ? consultation.Acte!.Libelle
        : lignesTries[0].Acte!.Libelle;
}
```
