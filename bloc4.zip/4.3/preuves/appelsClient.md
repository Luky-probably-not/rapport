# Appels au client

## Repository

```csharp
public async Task<ListerDecomptesEdiGelesOutput> ListerDecomptesEdiGelesAsync(string identifiantAssure, CancellationToken cancellationToken)
{
    var cultureInfo = cultureService.GetCulture();

    var taskListerValeurPharmacie = ListerNomenclaturesAsync(GroupePharmacie, cultureInfo, cancellationToken);
    var taskListerValeurBiologie = ListerNomenclaturesAsync(GroupeBiologie, cultureInfo, cancellationToken);
    var taskListerValeurDentaire = ListerNomenclaturesAsync(GroupeDentaire, cultureInfo, cancellationToken);
    var taskListerValeurActes = ListerValeurActeFrancaisAsync(cancellationToken);
    var taskListerDecomptes = ListerDecomptesAsync(identifiantAssure, cancellationToken);

    await Task.WhenAll(
        taskListerValeurPharmacie,
        taskListerValeurBiologie,
        taskListerValeurDentaire,
        taskListerValeurActes,
        taskListerDecomptes);

    var ncltPharmacie = (await taskListerValeurPharmacie)?.Valeurs.Select(v => v.Code) ?? [];
    var ncltBiologie = (await taskListerValeurBiologie)?.Valeurs.Select(v => v.Code) ?? [];
    var ncltDentaire = (await taskListerValeurDentaire)?.Valeurs.Select(v => v.Code) ?? [];
    //Trie les codeActe pour n'avoir que ceux contenant Consultation
    var ncltConsultation = (await taskListerValeurActes)?.Valeurs
        .Where(v => v.LibelleLong.Contains(Consultation, StringComparison.InvariantCultureIgnoreCase))
        .Select(v => v.Code.Trim()) ?? [];
    var decomptes = await taskListerDecomptes;

    return decomptes.CreerOutput([..ncltPharmacie, ..ncltBiologie, ..ncltDentaire], ncltConsultation);
}

/// Appel au bpm pour lister les décomptes
private async Task<ClientPS.IO.ListerDecomptesEdiGelesAssureOutput?> ListerDecomptesAsync(string identifiantAssure, CancellationToken cancellationToken)
{
    return (await clientPrestationSante.ListerDecomptesEdiGelesAssuresAsync(new ClientPS.IO.ListerDecomptesEdiGelesAssureInput{IdentifiantAssure = identifiantAssure},
            new ListerDecomptesEdiGelesErrorHandler(identifiantAssure), cancellationToken))
        .WhenError(r => new ClientException(r.Erreur.GetValueOrDefault()))
        .WhenUndefinedError(() => new RecuperationDecomptesEdiGelesImpossibleException(identifiantAssure)).Value;
}

/// Appel à NR2 pour lister les nomenclatures Spécialité de partenaire appartenant au groupe défini
private async Task<ClientNclt.IO.ConsulterListesValeursOutput?> ListerNomenclaturesAsync(string codeGroupe, CultureInfo codeCulture, CancellationToken cancellationToken)
{
    return await cacheService.GetOrCreateAsync($"{nameof(ListerNomenclaturesAsync)}_{codeGroupe}_{codeCulture}",
        async () =>
            (await clientNomenclature.ConsulterListeValeursAsync(
                "L_SPPS",
                new ClientNclt.IO.ConsulterListesValeursFiltre { UniquementActif = true, CodeGroupe = codeGroupe, InclureGroupe = false},
                cancellationToken))
            .WhenError(r => new ClientException(r.Erreur.GetValueOrDefault()))
            .WhenUndefinedError(() => new RecuperationSpecialitePartenaireImpossibleException(codeGroupe)).Value
        , _dureeCacheGlissante, ignoreSessionKeys:true);
}

/// Appel à NR2 pour lister les Code Actes
private async Task<ClientNclt.IO.ConsulterListesValeursOutput?> ListerValeurActeFrancaisAsync(CancellationToken cancellationToken)
{
    return await cacheService.GetOrCreateAsync($"{nameof(ListerNomenclaturesAsync)}_{CultureFr}",
        async () =>
            (await clientNomenclature.ConsulterListeValeursAsync(
                "ACHE",
                new ClientNclt.IO.ConsulterListesValeursFiltre { UniquementActif = true, InclureGroupe = false, Langue = CultureFr },
                cancellationToken))
            .WhenError(r => new ClientException(r.Erreur.GetValueOrDefault()))
            .WhenUndefinedError(() => new RecuperationCodeActeImpossibleException()).Value
        , _dureeCacheGlissante, ignoreSessionKeys: true);
}
```