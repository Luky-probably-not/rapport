# Méthode SplitIdentifiant

```csharp
private static (int idFichier, int idLot, int idDecompteArchive) SplitIndentifiantDecompte(this string idDecompteEdi)
{
    var splits = idDecompteEdi.Split("-", StringSplitOptions.RemoveEmptyEntries);
    if (splits.Length != 3
        || !int.TryParse(splits[0], out var idFichier) 
        || !int.TryParse(splits[1], out var idLot)
        || !int.TryParse(splits[2], out var idDecompteArchive))
    {
        throw new IdentifiantDecompteInvalideException(idDecompteEdi);
    }

    return (idFichier, idLot, idDecompteArchive);
}
```
