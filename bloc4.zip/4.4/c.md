# Activité 4.4 : Contrôler les flux de données entre les logiciels

J'ai acquis cette compétence lors du développement de plusieurs fonctionnalités du **BFF Assuré**.

Le rôle du BFF (Backend For Frontend) est de servir d'intermédiaire entre les applications clientes et les différents services du système d'information. Il permet ainsi d'assurer les échanges de données entre plusieurs logiciels tout en masquant leur complexité aux consommateurs.

Dans l'architecture mise en place, le BFF communique principalement avec les APIs BPM et NR2 au travers des projets Clients mis à disposition par chaque module métier.

Le flux de données peut être représenté de la manière suivante :

```text
Application cliente
        │
        ▼

   BFF Assuré
        │
        ▼

  Projet Client
        │
        ▼

     API BPM
        │
        ▼

     API NR2
        │
        ▼

  Base de données
```

Lorsqu'une fonctionnalité est exécutée, le BFF importe les données provenant des APIs métier puis les transforme afin de les adapter aux besoins du front avant de les réexporter sous un format simplifié.

Par exemple, pour la fonctionnalité de consultation des décomptes EDI gelés :

```text
      Front
        │
        ▼

    BFF Assuré
        │
        ▼

Client Prestations Santé
        │
        ▼

    API BPM
        │
        ▼

    DTO BPM
        │
        ▼

  Transformation BFF
        │
        ▼

     DTO BFF
        │
        ▼

      Front
```

Les échanges entre les différentes applications reposent sur des DTOs communs transportés au format JSON. L'utilisation des projets Clients permet de garantir la compatibilité entre les systèmes émetteurs et récepteurs tout en limitant les risques d'erreur liés à la sérialisation ou à l'évolution des contrats d'échange.

Afin de faciliter le contrôle des flux de données, chaque client encapsule :

- les points d'entrée de l'API distante
- les DTOs d'entrée
- les DTOs de sortie
- la configuration HTTP
- les mécanismes de sérialisation
- la gestion des erreurs technique

Cette approche permet de mesurer et contrôler les flux de données échangés entre le BFF et les différents services métier. Elle garantit également que les données transmises restent cohérentes tout au long de la chaîne de traitement.

L'ensemble des fonctionnalités développées repose ainsi sur des flux synchrones maîtrisés permettant l'importation, la transformation puis l'exportation des données entre plusieurs logiciels du système d'information.

Cette activité m'a permis d'acquérir une compréhension approfondie des mécanismes d'échange de données entre applications et des contraintes liées à la compatibilité des systèmes communiquant entre eux.
