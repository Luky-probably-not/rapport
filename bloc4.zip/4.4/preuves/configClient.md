# Configuration Client

```csharp
public static IServiceCollection AddModuleNomenclaturesClient(
  this IServiceCollection services,
  IConfiguration configuration)
{
  services.AddModuleClient<INomenclaturesClient, NomenclaturesClient>(configuration, "Nomenclatures");
  return services;
}
```

```json
"Nomenclatures": {
  "UseTransport": "http",
  "HttpTransport": {
    "Endpoint": "https://dev-apim.henner.local/dev_05/nr2/api/v1/"
  }
},
```
