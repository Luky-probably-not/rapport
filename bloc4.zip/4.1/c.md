# Activité 4.1 : Rétro-documentation de logiciels et de bases de données

J'ai acquis cette compétence lors de la réalisation de la documentation technique du **SQLLogRebuilder**, un outil interne utilisé par les développeurs de l'entreprise.

Cet outil permet de transformer les requêtes SQL présentes dans les logs générés par Entity Framework en requêtes SQL directement exploitables dans des outils d'analyse tels que DBeaver. Il facilite notamment les phases d'investigation et de diagnostic en permettant de reproduire localement les requêtes exécutées par les applications.

Le SQLLogRebuilder existait déjà avant mon intervention. Afin de produire une documentation fiable et exploitable, j'ai commencé par analyser son fonctionnement à partir de son code source et de son comportement lors de l'exécution.

Cette analyse m'a permis d'identifier :

- les formats de logs acceptés
- les données d'entrée utilisées par l'application
- les différents traitements effectués
- les données de sortie produites
- les cas d'utilisation principaux de l'outil

J'ai notamment constaté que l'application était capable de traiter des logs provenant de plusieurs sources :

- un fichier contenant des logs
- le contenu du presse-papier

ainsi que des logs de plusieurs formats :

- des logs au format Elastic/Kibana
- des logs récupérés depuis un terminal

Le fonctionnement général de l'outil peut être résumé par le processus suivant :

```text
Logs Entity Framework
        ↓
Analyse des paramètres SQL
        ↓
Récupération des valeurs associées
        ↓
Remplacement des paramètres
        ↓
Reconstruction de la requête SQL
        ↓
Script SQL exploitable dans DBeaver
```

Après avoir compris le fonctionnement du logiciel, j'ai rédigé une documentation présentant :

- l'objectif de l'outil
- son paramétrage
- les fichiers utilisés
- les différents modes d'utilisation
- les données d'entrée attendues
- les données produites en sortie

La documentation explique notamment les deux principaux modes de fonctionnement :

- reconstruction des requêtes depuis un fichier de logs ;
- reconstruction des requêtes à partir du contenu du presse-papier.

Elle permet aujourd'hui à un développeur de comprendre rapidement le rôle du SQLLogRebuilder et de l'utiliser sans avoir à analyser directement son implémentation.

Cette activité m'a permis de développer ma capacité à étudier un logiciel existant, à comprendre son fonctionnement interne puis à formaliser ces connaissances sous forme d'une documentation technique fiable, utilisable et maintenable par les membres de l'équipe.
