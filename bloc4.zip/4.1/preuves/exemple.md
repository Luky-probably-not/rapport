# Exemple de conversion

## Format txt

### Avant

```txt
[00;00;00]
[Parameters=[@__param='test']]
SELECT * FROM table WHERE t.value = @__param
```

### Après

```sql
SELECT *
FROM table
WHERE t.value = 'test";
```

## Format Kibana/Elastic

### Avant

```json
{ 
"Fields" :
    {
        "json.parameters" : ["@__param1='value1'"],
        "json.commandText" : ["-- Module\n-- File: /test/test.cs:489\n\nSELECT * FROM table WHERE t.value = @__param1"]
    }
}
```

### Après

```sql
SELECT *
FROM table
WHERE t.value = 'value1';
```
