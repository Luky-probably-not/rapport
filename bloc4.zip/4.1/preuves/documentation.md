# SqlLogRebuilder

Cet outil permet d'extraire les requêtes SQL des logs Nr2 et de les reconstruire avec les valeurs des paramètres.
Il peut récupérer les logs depuis le fichier spécifié ou depuis le presse-papier. Les logs doivent être au format d'Elastic/Kibana ou depuis un terminal.

Toutes les requêtes présentes dans le fichier/presse-papier seront traitées.

## Paramétrage

- LogSource : Définie le fichier source contenant la log
- FichierSortie : Définie le fichier de destination avec les requêtes reconstruites

## Utilisation

Dans le paramétrage, renseignez l'emplacement du fichier d'entrée et de sortie. Veillez à ce qu'ils ne se trouve pas dans le répertoire git.
Lancez l'application.

![image](_static/image.png)

### Reconstruire requêtes depuis fichier

L'option A - Reconstruire requêtes depuis fichier utilise les fichiers renseignés. Il analyse le fichier d'entrée, et reconstruit la ou les requetes trouvés dedans, avant de les mettre dans le fichier de sortie.

### Reconstruire requêtes depuis presse-papier

L'option B - Reconstruire requêtes depuis presse-papier analyse le contenu que vous avez copié, et reconstruit la ou les requêtes avant de les coller dans votre presse-papier, prètes à être utilisées.
