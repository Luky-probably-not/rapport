# Activité 4.5 : Réalisation d’un environnement de tests

J'ai acquis cette compétence lors du développement du projet **ITeralis**, une plateforme communautaire permettant la consultation et le partage de cours de cybersécurité.

Afin de faciliter le développement, les tests et le déploiement de l'application, j'ai mis en place un environnement complet permettant de reproduire localement l'architecture d'exécution de la solution.

L'application repose sur une architecture multi-tiers composée de plusieurs composants :

- une base de données MariaDB ;
- une API .NET 8 ;
- une application Web développée avec Deno/Fresh.

Afin d'automatiser l'installation et la configuration de ces différents éléments, j'ai utilisé **Docker** et **Docker Compose**.

Le fichier `docker-compose.yml` permet de créer automatiquement l'ensemble des composants nécessaires à l'exécution de l'application :

```text
Frontend (Deno/Fresh)
          │
          ▼
      API .NET
          │
          ▼
       MariaDB
```

L'architecture est organisée autour de trois conteneurs :

## Conteneur base de données

Le conteneur `bdd` repose sur une image MariaDB et initialise automatiquement la base grâce à un script SQL exécuté au démarrage.

Il assure :

- le stockage des données ;
- l'exécution du script d'initialisation ;
- la persistance des données via un volume Docker ;
- la vérification automatique de disponibilité grâce à un HealthCheck.

## Conteneur API

Le conteneur `api` est généré automatiquement à partir du code source de l'application.

Le Dockerfile réalise plusieurs étapes :

```text
Restauration des dépendances
        ↓
Compilation
        ↓
Publication .NET
        ↓
Création de l'image finale
```

Cette approche garantit que la version exécutée dans l'environnement de test est identique à celle qui sera déployée ultérieurement.

## Conteneur Frontend

Le conteneur `front` est construit à partir d'une image Deno.

Lors du build :

```text
Copie du code source
        ↓
Installation des dépendances
        ↓
Compilation de l'application
        ↓
Démarrage du serveur Web
```

Le front peut ainsi communiquer directement avec l'API au travers du réseau Docker prévu à cet effet.

## Isolation des flux réseau

Afin de reproduire un environnement proche de la production, deux réseaux Docker distincts ont été mis en place :

```text
iteralis-frontend

Front
    ↓
API
```

```text
iteralis-backend

API
    ↓
MariaDB
```

Cette séparation empêche l'application web d'accéder directement à la base de données et garantit que l'ensemble des échanges passe obligatoirement par l'API.

## Automatisation de l'environnement

Le démarrage de l'ensemble de la plateforme est réalisé par une seule commande :

```bash
docker compose up
```

Cette commande :

- construit les images ;
- crée les conteneurs ;
- crée les réseaux ;
- démarre MariaDB ;
- démarre l'API ;
- démarre l'application Web ;
- configure automatiquement les communications entre les services.

L'arrêt complet de l'environnement s'effectue simplement avec :

```bash
docker compose down
```

## Schéma de l'environnement de tests

```text
┌─────────────────────┐
│ Frontend Deno/Fresh │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│      API .NET 8     │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│      MariaDB 11     │
└─────────────────────┘
```

La mise en place de cet environnement m'a permis de disposer d'une plateforme complète de développement et de validation, fidèle à l'architecture réelle de l'application. L'ensemble des composants peut être déployé de façon reproductible sur n'importe quelle machine disposant de Docker, ce qui facilite les tests techniques et garantit l'homogénéité des environnements utilisés par les différents développeurs du projet.
