# DockerFiles

## BDD

```txt
FROM mariadb:11

COPY data/init.sh /docker-entrypoint-initdb.d/
```

## API

```txt
# ─── STAGE BUILD ───────────────────────────────────────────────

FROM mcr.microsoft.com/dotnet/sdk:8.0 AS build

COPY ["ITeralis.Abstractions/ITeralis.Abstractions.csproj", "ITeralis.Abstractions/"]
COPY ["ITeralis.Application/ITeralis.Application.csproj", "ITeralis.Application/"]
COPY ["ITeralis.Controllers/ITeralis.Controllers.csproj", "ITeralis.Controllers/"]
COPY ["ITeralis.Domain/ITeralis.Domain.csproj", "ITeralis.Domain/"]
COPY ["ITeralis.Repository/ITeralis.Repository.csproj", "ITeralis.Repository/"]
COPY ["ITeralis.Utilitaires/ITeralis.Utilitaires.csproj", "ITeralis.Utilitaires/"]

RUN dotnet restore "ITeralis.Application/ITeralis.Application.csproj"

COPY . .
WORKDIR /ITeralis.Application

RUN dotnet publish "ITeralis.Application.csproj" -c Release -o /app/publish

# ─── STAGE RUNTIME ─────────────────────────────────────────────

FROM mcr.microsoft.com/dotnet/aspnet:8.0 AS final
WORKDIR /app

EXPOSE 8080
COPY --from=build /app/publish .

ENTRYPOINT [ "dotnet", "ITeralis.Application.dll" ]
```

## Front

```txt
FROM denoland/deno:2.2.4

ARG GIT_REVISION=dev
ENV DENO_DEPLOYMENT_ID=${GIT_REVISION}

WORKDIR /app

COPY deno.json .

COPY . .

RUN deno install
RUN deno task build

EXPOSE 7000

CMD ["deno", "serve", "-A", "main.ts"]
```