# Activité 4.2 : Mise au point de tables de correspondance de données

J'ai acquis cette compétence lors du développement de la fonctionnalité **ListerDecomptesEdiGeles** du BFF Assuré.

Le rôle du BFF est de simplifier les échanges entre les applications clientes et les APIs du système d'information. Pour cela, il doit transformer les objets retournés par les APIs métiers afin de les adapter aux besoins des applications consommatrices.

Dans le cadre de cette fonctionnalité, le module **Décomptes EDI Gelés** du BPM retourne un ensemble de DTOs qui ne correspondent pas directement au contrat exposé par le BFF. J'ai donc mis en place un composant de mapping chargé d'assurer la correspondance entre les structures de données des deux applications.

Le flux de transformation est le suivant :

```text
API BPM

ListerDecomptesEdiGelesAssureOutput

                ↓

ListerDecomptesEdiGelesMapper

                ↓

ListerDecomptesEdiGelesOutput

                ↓

Application cliente
```

Le mapper centralise l'ensemble des règles de correspondance entre les objets BPM et les objets du BFF.

Par exemple, les informations du bénéficiaire sont transformées selon les règles suivantes :

| DTO BPM                       | DTO BFF                       |
| ----------------------------- | ----------------------------- |
| Identifiant                   | Identifiant                   |
| Nom                           | Nom                           |
| Prenom                        | Prenom                        |
| NumeroNationalImmatriculation | NumeroNationalImmatriculation |

De la même manière, les montants sont convertis vers le contrat exposé par le BFF :

| DTO BPM | DTO BFF |
| ------- | ------- |
| Valeur  | Montant |
| Devise  | Devise  |

Une correspondance particulière a également été mise en place pour l'identifiant du décompte. Le BPM retourne un identifiant unique contenant plusieurs informations métier :

```text
125-78-456
```

Le BFF doit exposer ces informations dans trois propriétés distinctes :

| Donnée source BPM      | Donnée cible BFF           |
| ---------------------- | -------------------------- |
| IdentifiantDecompteEdi | IdentifiantFichier         |
| IdentifiantDecompteEdi | IdentifiantLot             |
| IdentifiantDecompteEdi | IdentifiantDecompteArchive |

Cette transformation est réalisée par la méthode :

```csharp
SplitIndentifiantDecompte()
```

Le composant de mapping garantit ainsi que chaque donnée manipulée par le BPM possède une correspondance clairement définie dans le modèle exposé par le BFF.

Cette approche facilite la maintenance du système tout en garantissant qu'aucune donnée nécessaire au fonctionnement de l'application cliente ne soit perdue lors des échanges entre les différentes applications.

Cette activité m'a permis d'analyser les modèles de données de deux applications distinctes puis de formaliser les règles de correspondance nécessaires à leurs échanges.
