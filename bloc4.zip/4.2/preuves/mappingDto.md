# Mapping de dto

## Sortie BPM

```json
{
  "decomptesEdiGeles": [
    {
      "identifiantDecompteEdi": "123-1-456",
      "identifiantDecompteSS": 654987321,
      "beneficiaire": {
        "identifiant": "123-P",
        "nom": "DOE",
        "prenom": "JOHN",
        "numeroNationalImmatriculation": "7865432198"
      },
      "dateDebutSoin": "2026-06-12T00:00:00",
      "dateFinSoin": "2026-06-12T00:00:00",
      "estEnAttenteFacture": false,
      "montantDepense": {
        "valeur": 25,
        "devise": "EUR"
      },
      "remboursementPartComplementaire": null,
      "remboursementSS": {
        "valeur": 17.5,
        "devise": "EUR"
      },
      "lignesDecompteEdi": [
        {
          "identifiantLigneDecompteEdi": 1,
          "acte": {
            "code": "C",
            "libelle": "Consultation"
          }
        }
      ],
      "partenaireExecutant": {
        "identifiant": 9873231687321,
        "specialite": {
          "code": "001",
          "libelle": "Médecine générale"
        }
      }
    },
  ]
}
```

## Sortie BFF

```json
{
    "DecomptesEdiGeles":[
        {
            "identifiantFichier": 123,
            "identifiantLot": 1,
            "identifiantDecompteArchive": 456,
            "identifiantDecompteSS": 654987321,
            "libelleDecompteArchive": "Consultation",
            "beneficiaire": {
                "identifiant": 123,
                "nom": "DOE",
                "prenom": "JOHN",
                "numeroNationalImmatriculation": "7865432198"
            },
            "dateDebutSoin": "2026-06-12T00:00:00",
            "dateFinSoin": "2026-06-12T00:00:00",
            "estEnAttenteFacture": false,
            "montantDepense": {
                "montant": 25,
                "devise": "EUR"
            },
            "remboursementPartComplementaire": null,
            "remboursementSS": {
                "montant": 17.5,
                "devise": "EUR"
            },
        }
    ]
}
```
