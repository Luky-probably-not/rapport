# Mapper

```csharp
public static ListerDecomptesEdiGelesOutput CreerOutput(
    this ClientPS.IO.ListerDecomptesEdiGelesAssureOutput? outputClient, IEnumerable<string> nomenclatures, IEnumerable<string> consultations)
        => new ListerDecomptesEdiGelesOutput
    {
        DecomptesEdiGeles = outputClient?.DecomptesEdiGeles.Select(d =>
        {
            var (idFichier, idLot, idDecompteArchive) = d.IdentifiantDecompteEdi.SplitIndentifiantDecompte();
            return new DecompteEdiGelesDto
            {
                IdentifiantFichier = idFichier,
                IdentifiantLot = idLot,
                IdentifiantDecompteArchive = idDecompteArchive,
                IdentifiantDecompteSS = d.IdentifiantDecompteSS,
                LibelleDecompteArchive = d.TrouverLibelleDecompte(nomenclatures, consultations) ?? string.Empty,
                Beneficiaire = new BeneficiaireDto
                {
                    Identifiant = d.Beneficiaire.Identifiant.ConvertIdentifiantAssure(),
                    Nom = d.Beneficiaire.Nom,
                    Prenom = d.Beneficiaire.Prenom,
                    NumeroNationalImmatriculation = d.Beneficiaire.NumeroNationalImmatriculation
                },
                DateDebutSoin = d.DateDebutSoin,
                DateFinSoin = d.DateFinSoin,
                EstEnAttenteFacture = d.EstEnAttenteFacture,
                TotalDepense = d.MontantDepense.CreerMontant()!,
                PartComplementaire = d.RemboursementPartComplementaire.CreerMontant(),
                RemboursementSS = d.RemboursementSS.CreerMontant()!
            };
        }) ?? []
            
    };

private static (int idFichier, int idLot, int idDecompteArchive) SplitIndentifiantDecompte(this string idDecompteEdi)
{
    var splits = idDecompteEdi.Split("-", StringSplitOptions.RemoveEmptyEntries);
    if (splits.Length != 3
        || !int.TryParse(splits[0], out var idFichier) 
        || !int.TryParse(splits[1], out var idLot)
        || !int.TryParse(splits[2], out var idDecompteArchive))
    {
        throw new IdentifiantDecompteInvalideException(idDecompteEdi);
    }

    return (idFichier, idLot, idDecompteArchive);
}

private static MontantDto? CreerMontant(this ClientShared.MontantDto? montant)
{
    return montant == null
        ? null
        : new MontantDto
        {
            Montant = montant.Valeur,
            Devise = montant.Devise
        };
}

/// Applique la règle de gestion PRS-DEC-007
private static string? TrouverLibelleDecompte(this ClientPS.DecompteEdiGelesDto decompte, IEnumerable<string> nomenclatures, IEnumerable<string> consultations)
{
    var partenaire = decompte.PartenaireExecutant;

    if (nomenclatures.Contains(partenaire?.Specialite.Code))
    {
        return partenaire!.Specialite.Libelle;
    }

    var lignes = decompte.LignesDecompteEdi;
    var lignesTries = lignes.Where(d => d.Acte != null).OrderBy(d => d.IdentifiantLigneDecompteEdi).ToList();
    if (!lignesTries.Any())
    {
        return null;
    }

    var consultation = lignesTries.FirstOrDefault(l => consultations.Contains(l.Acte?.Code));
    return consultation != null
        ? consultation.Acte!.Libelle
        : lignesTries[0].Acte!.Libelle;
}
```
