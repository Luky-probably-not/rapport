# Activité 1.7 : Détermination du nombre de tiers de l'application

J'ai acquis cette compétence lors de la conception de l'architecture d'ITeralis, une plateforme permettant la consultation et le partage de cours de cybersécurité.

Dès la phase de conception, j'ai défini une architecture reposant sur plusieurs tiers distincts afin de répartir les responsabilités de l'application et d'anticiper une éventuelle augmentation du nombre d'utilisateurs.

L'application est composée de :

- un tiers de présentation correspondant à l'application web ;
- un tiers applicatif correspondant à l'API .NET ;
- un tiers de données reposant sur MariaDB ;

Cette séparation permet de répartir les traitements en fonction de leur nature. Les interfaces utilisateur sont gérées par le clients web, la logique métier est centralisée dans l'API et les données sont stockées dans une base dédiée.

```txt
Application Web
      |
      v
     API
      |
      v
    MariaDB
```

Lors de cette conception, j'ai également isolé les différents composants dans des conteneurs Docker distincts. Cette approche permet de faire évoluer indépendamment chaque tiers en fonction de la charge observée.

L'API a été conçue sous la forme d'un service REST sans état (stateless). Ce choix facilite la montée en charge puisque plusieurs instances de l'API pourraient être déployées simultanément sans modification de la logique applicative. De la même manière, l'ajout d'un nouveau client consommant l'API ne nécessite pas la création d'un nouveau backend spécifique.

J'ai également mis en place une séparation réseau entre les services. La base de données n'est accessible que par l'API et n'est jamais exposée directement aux applications clientes. Cette organisation limite les accès directs aux données et réduit la charge supportée par le tiers le plus sensible du système.

Cette architecture me permet d'anticiper les évolutions futures de la plateforme en répartissant les traitements entre plusieurs tiers spécialisés et en conservant la possibilité d'augmenter indépendamment les ressources allouées à chacun d'eux.