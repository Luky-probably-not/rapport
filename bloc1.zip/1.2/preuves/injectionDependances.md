# Injection de dépendances

Program.cs

```csharp
var connectionString = builder.Configuration.GetConnectionString("MariaDbConnectionString");

if (string.IsNullOrEmpty(connectionString)) {
    throw new NoNullAllowedException(nameof(connectionString));
}
builder.Services.AjoutUtilisateurContext(connectionString);
builder.Services.AjoutMatiereContext(connectionString);
builder.Services.AjoutCategorieContext(connectionString);
builder.Services.AjoutCoursContext(connectionString);
builder.Services.AjoutImageContext(connectionString);
```

## ITeralis.Repository

```csharp
public static IServiceCollection AjoutCoursContext(this IServiceCollection services,
    string connectionString)
{
    services.AddDbContext<CoursDbContext>(options =>
        options.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString)));

    services.AddScoped<ICoursRepository, CoursRepository>();

    return services;
}
```
