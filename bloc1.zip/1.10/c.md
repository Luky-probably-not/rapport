# Activité 1.10 : Amélioration de la qualité du logiciel et du code produit

J'ai acquis cette compétence lors du développement du CatchErrorBuilder, une bibliothèque mise à disposition des différentes API BFF de l'entreprise afin de centraliser et standardiser la gestion des erreurs.

Avant la mise en place de cette solution, chaque endpoint implémentait sa propre logique de gestion des exceptions. Cette approche entraînait une duplication de code importante ainsi qu'un risque d'incohérence dans les réponses retournées aux consommateurs des endpoints.

Afin d'améliorer la qualité du code produit, j'ai conçu le CatchErrorBuilder en appliquant les principes de la programmation orientée objet. Cette centralisation permet également de garantir un comportement homogène face aux erreurs et de limiter les risques d'oublis ou d'implémentations incohérentes entre les différents endpoints.

Cette approche présente plusieurs avantages :

- réduction de la duplication de code ;
- amélioration de la lisibilité des traitements ;
- centralisation de la logique de gestion des exceptions ;
- simplification de la maintenance ;
- uniformisation des réponses d'erreur produites par les endpoints.

Le composant a été conçu afin d'être réutilisable dans plusieurs applications. Ainsi, lorsqu'une évolution ou une correction doit être effectuée sur la gestion des erreurs, celle-ci est réalisée à un seul endroit puis bénéficie automatiquement à l'ensemble des applications utilisant cette bibliothèque.

Cette mutualisation a permis d'améliorer la robustesse globale des API tout en facilitant leur évolution future. Elle contribue également à maintenir une architecture cohérente, un niveau de qualité homogène entre les différents projets de l'entreprise et à réduire significativement la duplication de code.

Le développement de cette bibliothèque a également respecté les conventions de nommage et les standards de développement utilisés au sein de l'entreprise afin de faciliter sa compréhension et sa maintenance par les autres développeurs.

Aujourd'hui, le composant est utilisé dans l'API BFF Assuré. Son architecture a été pensée pour être réutilisable dans les autres API BFF de l'entreprise, permettant ainsi de mutualiser la gestion des erreurs et de conserver un comportement homogène entre les différents services.
