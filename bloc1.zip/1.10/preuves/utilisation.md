# CatchErrorBuilder

## Exemple d'utilisation

```csharp
private static async Task<IResult> ListerDemandes(
    [FromRoute(Name = "identifiant-personne")] int identifiantAssure,
    [FromServices] IListerDemandeRepository repository,
    [FromServices] ICatchErrorBuilder errorBuilder,
    CancellationToken cancellationToken)
{
    var identifiant = identifiantAssure.ConvertIdentifiantAssure();

    return await errorBuilder.DefinirTraitement(async () =>
        {
            var output = await repository.ListerDemandeAssure(identifiant, cancellationToken);

            return output.Demandes.Any()
                ? Results.Ok(output)
                : Results.NoContent();
        }).OnDonneeNonTrouvee(_ => Results.NoContent())
        .Executer();
}
```

## Avant

```csharp
private static async Task<IResult> ListerDemandes(
    [FromRoute(Name = "identifiant-personne")] int identifiantAssure,
    [FromServices] IListerDemandeRepository repository,
    CancellationToken cancellationToken)
{
    var identifiant = identifiantAssure.ConvertIdentifiantAssure();

    try {
        var output = await repository.ListerDemandeAssure(identifiant, cancellationToken);

        return output.Demandes.Any()
            ? Results.Ok(output)
            : Results.NoContent();
    } catch (DonneeNonTrouveeException e)
    {
        return Results.NoContent();
    }
}
```

## Extrait

```csharp
public async Task<IResult> Executer()
{
    if (_process == null)
    {
        throw new TraitementNullException();
    }
    try
    {
        return await _process.Invoke();
    }
    catch (Exception e)
    {
        if (e is BaseException baseException)
        {
            if (_dictionaryErreur.TryGetValue(baseException.Type, out var func))
            {
                logger.LogWarning(e, "Erreur attrapée : '{ErrorCode}'", baseException.ErrorCode);
                return func(_baseExceptionConvertor(baseException));
            }
            else
            {
                return UndefinedCatch(baseException, baseException.ErrorCode);
            }
        }

        return UndefinedCatch(e, e.GetType().Name);
    }
}
```
