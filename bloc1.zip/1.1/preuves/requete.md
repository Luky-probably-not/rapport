# Exemples requêtes

## Avant

### {{urlApi}}/api/v1/nomenclatures/PAYS

> [!NOTE]Renvoit
>
> ```json
> {
>   "valeurs": [
>     {
>       "code": "AC ",
>       "estGroupe": false,
>       "libelleCourt": "Ile de l'Ascension",
>       "libelleLong": "Ile de l'Ascension"
>     },
>     {
>       "code": "AD ",
>       "estGroupe": false,
>       "libelleCourt": "ANDORRE",
>       "libelleLong": "ANDORRE"
>     },
>   ]
> }
> ```

## Après

### {{urlApi}}/api/v1/nomenclatures/PAYS?codeGroupe=945

> [!NOTE]Renvoit
>
> ```json
> {
>   "valeurs": [
>     {
>       "code": "AE ",
>       "estGroupe": false,
>       "libelleCourt": "EMIRATS ARABES UNIS",
>       "libelleLong": "EMIRATS ARABES UNIS"
>     },
>     {
>       "code": "AU ",
>       "estGroupe": false,
>       "libelleCourt": "AUSTRALIE",
>       "libelleLong": "AUSTRALIE"
>     },
>   ]
> }
> ```
