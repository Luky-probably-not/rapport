### Consulter une liste de valeur

Cette fonctionnalité permet de sortir l'intégralité d'une liste valeur

#### Permission nécessaire

```{important}
TODO > Ajouter des permissions
```

| Permission |
| ---------- |
|            |

#### Paramètres

| Description                | Type   | Obligatoire |
| -------------------------- | ------ | ----------- |
| Code de la liste de valeur | string | Oui         |
| Filtre du code de groupe   | string | Non         |

#### Informations en sortie

| Description      | Type                      |
| ---------------- | ------------------------- |
| Liste de valeurs | [ValeurDto[]](#valeurdto) |

##### ValeurDto

| Description                           | Type   | Obligatoire |
| ------------------------------------- | ------ | ----------- |
| Code de la valeur                     | string | Oui         |
| Indicateur si la valeur est un groupe | bool   | Oui         |
| Libelle court                         | string | Oui         |
| Libelle long                          | string | Oui         |
