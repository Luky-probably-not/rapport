# Activité 1.9 : Estimation, qualification des risques de sécurité

J'ai acquis cette compétence dans le cadre de l'évolution du système RBAC (Role Based Access Control) de l'entreprise.

Lors de cette évolution, les permissions précédemment définies dans le code source ont été externalisées dans des fichiers JSON afin de permettre une configuration plus flexible et de faciliter leur maintenance.

Cette nouvelle architecture apporte de nombreux avantages, mais elle introduit également de nouveaux risques de sécurité et de disponibilité. J'ai donc procédé à une analyse des risques associés à l'utilisation de ces fichiers de configuration.

J'ai notamment identifié le risque lié à la présence d'un fichier JSON invalide ou corrompu. En effet, si un fichier de permissions devient illisible à la suite d'une erreur de syntaxe ou d'une modification incorrecte, l'API n'est plus en mesure de déterminer correctement les permissions associées à un utilisateur. Cette situation peut entraîner des erreurs d'exécution et empêcher l'accès à certaines fonctionnalités.

J'ai évalué ce risque comme étant de criticité élevée en raison de son impact potentiel sur le fonctionnement du système d'autorisation de l'application.

Afin de réduire ce risque, j'ai proposé la mise en place d'un mécanisme de validation automatique des fichiers JSON lors des pipelines CI/CD. Cette validation pourrait s'appuyer sur un schéma JSON permettant de vérifier la structure, les types et les champs obligatoires avant tout déploiement d'une modification.  
Actuellement, lorsqu'une anomalie est détectée lors du chargement ou de l'interprétation des fichiers JSON, l'API renvoie une erreur empêchant l'utilisation du système d'autorisation jusqu'à la correction du fichier concerné.  
Afin de faciliter les contrôles lors des évolutions du RBAC, j'ai également développé un endpoint permettant de visualiser l'ensemble des permissions associées à chaque profil utilisateur. Cette fonctionnalité permet de comparer rapidement les droits attendus avec les droits effectivement générés et constitue un moyen supplémentaire de détecter d'éventuelles anomalies après une modification de configuration.

Cette analyse a permis d'identifier plusieurs mesures préventives destinées à améliorer la sécurité, la fiabilité et la maintenabilité du système d'autorisation tout en limitant les risques d'erreur humaine lors des évolutions futures.

| Risque                           | Impact                                 | Criticité | Mesure préventive            |
| -------------------------------- | -------------------------------------- | --------- | ---------------------------- |
| JSON invalide                    | RBAC indisponible                      | Élevée    | Validation JSON Schema CI/CD |
| Permission manquante             | Refus d'accès inattendu                | Moyenne   | Contrôle automatique         |
| Cascade des permissions invalide | Erreur de construction des permissions | Élevée    | Validation structurelle      |
| Permissions dupliquées           | Attribution incorrecte des permissions | Moyenne   | Contrôle des doublons        |

[TODO] schéma fonctionnement RBAC
Fichier JSON
        |
        v
Chargement RBAC
        |
        +--> Contrôle structure
        |
        +--> Construction permissions
        |
        +--> Endpoint de vérification
        |
        v
Contrôle accès utilisateur