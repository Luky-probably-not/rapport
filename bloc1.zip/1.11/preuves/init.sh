#!/bin/bash
set -e

echo "[Init] Création des tables et utilisateurs..."

mariadb -u root -p"${MYSQL_ROOT_PASSWORD}" <<EOSQL

CREATE USER IF NOT EXISTS '${MYSQL_USERNAME}'@'%' IDENTIFIED BY '${MYSQL_USER_PASSWORD}';
GRANT INSERT, SELECT, UPDATE, DELETE ON \`${MYSQL_DATABASE}\`.* TO '${MYSQL_USERNAME}'@'%';

USE \`${MYSQL_DATABASE}\`;

CREATE TABLE IF NOT EXISTS Utilisateurs (
    idUtilisateur VARCHAR(255) NOT NULL PRIMARY KEY,
    UserName VARCHAR(15) NOT NULL UNIQUE,
    Email VARCHAR(64) NOT NULL UNIQUE,
    Password VARCHAR(255) NOT NULL,
    Role VARCHAR(15),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS Images (
    idImage VARCHAR(255) NOT NULL PRIMARY KEY,
    Image MEDIUMBLOB NOT NULL,
    Name VARCHAR(255) NOT NULL,
    TypeImage VARCHAR(25) NOT NULL
);

CREATE TABLE IF NOT EXISTS Droits (
    idUtilisateur VARCHAR(255) NOT NULL,
    ModifierPost BOOLEAN,
    VerifierPost BOOLEAN,
    SuppresionPost BOOLEAN,
    RestreindreUser BOOLEAN,
    UpdatePermissions BOOLEAN,
    FOREIGN KEY (idUtilisateur) REFERENCES Utilisateurs(idUtilisateur)
);

CREATE TABLE IF NOT EXISTS Categories (
    idCategorie VARCHAR(255) NOT NULL PRIMARY KEY,
    NomCategorie VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS Matieres (
    idMatiere VARCHAR(255) NOT NULL PRIMARY KEY,
    NomMatiere VARCHAR(50) NOT NULL,
    idImage VARCHAR(255),
    Vues INTEGER DEFAULT 0,
    Description VARCHAR(255),
    idUtilisateur VARCHAR(255) NOT NULL,
    idCategorie VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (idImage) REFERENCES Images(idImage),
    FOREIGN KEY (idUtilisateur) REFERENCES Utilisateurs(idUtilisateur),
    FOREIGN KEY (idCategorie) REFERENCES Categories(idCategorie)
);

CREATE TABLE IF NOT EXISTS Cours (
    idCours VARCHAR(255) NOT NULL PRIMARY KEY,
    Titre VARCHAR(255) NOT NULL,
    Contenu LONGTEXT,
    Vues INTEGER DEFAULT 0,
    Certifie BOOLEAN DEFAULT false,
    idUtilisateur VARCHAR(255) NOT NULL,
    idMatiere VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (idUtilisateur) REFERENCES Utilisateurs(idUtilisateur),
    FOREIGN KEY (idMatiere) REFERENCES Matieres(idMatiere)
);

FLUSH PRIVILEGES;
EOSQL

echo "[Init] Terminé avec succès"