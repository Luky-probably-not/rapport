# Activité 1.11 : Programmation de l'accès aux données de l'entreprise

J'ai acquis cette compétence lors de la conception et du développement de la base de données d'ITeralis, une plateforme communautaire permettant la consultation et le partage de cours de cybersécurité.

L'application manipule plusieurs types de données métier tels que les utilisateurs, les cours, les matières, les catégories, les images ainsi que les droits associés aux comptes utilisateurs. Afin de garantir la fiabilité des informations stockées et d'éviter toute corruption de la base de données, j'ai mis en place plusieurs mécanismes de sécurité et d'intégrité.

J'ai tout d'abord conçu le schéma relationnel de la base MariaDB en définissant des contraintes d'intégrité directement au niveau des tables. Chaque entité possède une clé primaire permettant d'assurer l'unicité des enregistrements.

J'ai également défini plusieurs clés étrangères afin de garantir la cohérence des relations entre les données. Par exemple, un cours doit obligatoirement être associé à une matière et un utilisateur existants. Il est donc impossible de créer un enregistrement faisant référence à une donnée inexistante.

Par ailleurs, certaines contraintes d'unicité ont été ajoutées afin d'empêcher les doublons sur les données sensibles de l'application. C'est notamment le cas des champs `UserName` et `Email`, qui doivent être uniques pour chaque utilisateur.

Afin d'améliorer la traçabilité des opérations réalisées sur la base, j'ai également mis en place des mécanismes automatiques de suivi des modifications. Les colonnes `created_at` et `updated_at` sont alimentées automatiquement par MariaDB grâce aux clauses `DEFAULT CURRENT_TIMESTAMP` et `ON UPDATE CURRENT_TIMESTAMP`, permettant de connaître la date de création et de dernière modification de chaque enregistrement sans intervention du code applicatif.

La sécurisation des accès a également été prise en compte lors de la conception de la solution. Plutôt que d'utiliser le compte administrateur de la base de données, j'ai créé un utilisateur applicatif dédié disposant uniquement des droits nécessaires au fonctionnement de l'application (`SELECT`, `INSERT`, `UPDATE` et `DELETE`). Cette approche applique le principe du moindre privilège et limite les conséquences potentielles d'un accès non autorisé à l'API.

Enfin, au niveau applicatif, les erreurs liées aux accès aux données sont contrôlées et converties en exceptions métier dédiées. Par exemple :

- `UtilisateurUniqueClauseException`
- `AucunCoursTrouveException`
- `MisAJourCoursImpossibleException`

Cette approche permet d'éviter l'exposition directe des erreurs SQL aux utilisateurs tout en fournissant des messages cohérents et exploitables par l'application.

L'ensemble de ces mécanismes contribue à garantir l'intégrité des données, à limiter les risques de corruption de la base et à sécuriser les accès aux informations manipulées par la plateforme ITeralis.
