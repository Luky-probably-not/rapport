# Activité 1.8 : Réalisation d'une interface homme/machine (IHM) adaptative aux situations de handicap

J'ai acquis cette compétence lors du développement d'Ecocoffee, un site vitrine e-commerce réalisé en Vue 3. Contrairement à mes projets principalement orientés API, ce projet m'a permis d'intervenir directement sur l'ensemble des interfaces utilisateur et d'appliquer les principes d'accessibilité numérique dès la phase de développement.

L'objectif était de concevoir une interface utilisable par le plus grand nombre, y compris par les personnes utilisant des technologies d'assistance telles que les lecteurs d'écran ou la navigation exclusivement au clavier.

Pour cela, j'ai conçu les différentes pages en utilisant un balisage HTML sémantique adapté. Les éléments de structure tels que header, nav, main, section, article ou footer ont été utilisés selon leur rôle réel afin de permettre aux technologies d'assistance de restituer correctement l'organisation de la page.

Afin d'améliorer la navigation au clavier, j'ai mis en place des liens d'évitement ("skip links") placés en début de page. Ces liens permettent d'accéder directement au contenu principal ou au formulaire de contact sans parcourir l'ensemble des éléments de navigation.

J'ai également structuré les différentes régions de la page à l'aide de l'attribut aria-labelledby. Chaque section est ainsi associée à un titre explicite permettant aux utilisateurs de lecteurs d'écran d'identifier rapidement le contenu proposé.

Une attention particulière a été portée aux formulaires. Pour chaque champ, j'ai associé un label explicite et utilisé des groupes de champs (fieldset et legend) lorsque cela était pertinent. Les erreurs de saisie sont annoncées de manière accessible grâce aux attributs aria-invalid, aria-describedby et au rôle alert, permettant à l'utilisateur d'être informé immédiatement d'une anomalie.

J'ai également différencié les images décoratives des images porteuses d'information. Les éléments purement visuels sont ignorés par les technologies d'assistance grâce à l'utilisation de alt="" et aria-hidden="true". À l'inverse, les informations utiles sont systématiquement restituées sous forme de contenu textuel structuré afin d'assurer leur accessibilité aux personnes malvoyantes ou non-voyantes.

Afin de prendre en compte les besoins des personnes sensibles aux animations, j'ai ajouté une gestion de la préférence système prefers-reduced-motion. Lorsque cette option est activée, les animations du site sont fortement réduites afin de limiter les risques d'inconfort liés aux mouvements.

Enfin, j'ai respecté plusieurs bonnes pratiques fondamentales d'accessibilité comme :

- la déclaration de la langue principale du document
- une hiérarchie cohérente des titres
- la conservation d'indicateurs de focus visibles
- une navigation complète au clavier

L'accessibilité a ainsi été prise en compte dès la conception de l'interface et non comme une correction ajoutée après développement. Cette démarche a permis de produire une interface plus inclusive, conforme aux recommandations du RGAA et des WCAG.