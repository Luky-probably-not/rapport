# Labels

```html
<template>
  <section id="contact" aria-labelledby="contact-form-titre">
    <h2 id="contact-form-titre">Nous contacter</h2>
    <form action="#" method="POST" novalidate @submit.prevent="handleSubmit">
      <fieldset>
        <legend class="sr-only">Informations de contact</legend>
        <label for="name">Prénom et nom (Obligatoire) :</label>
        <input
          type="text"
          id="name"
          name="name"
          placeholder="Entrez votre prénom et votre nom (ex : Gauthier Chicorée)"
          required
          autocomplete="name"
          :aria-describedby="nameError ? 'name-error' : null"
          aria-invalid="nameError ? 'true' : 'false'"
        />
        <span v-if="nameError" id="name-error" role="alert" class="error-message">
          {{ nameError }}
        </span>
      </fieldset>
      <fieldset>
        <legend class="sr-only">Email</legend>
        <label for="email">Email (Obligatoire) :</label>
        <input
          type="email"
          id="email"
          name="email"
          placeholder="Entrez votre email (ex : email@gmail.com)"
          required
          autocomplete="email"
          :aria-describedby="emailError ? 'email-error' : null"
          aria-invalid="emailError ? 'true' : 'false'"
        />
        <span v-if="emailError" id="email-error" role="alert" class="error-message">
          {{ emailError }}
        </span>
      </fieldset>
      <fieldset>
        <legend class="sr-only">Message</legend>
        <label for="message">Message (Obligatoire) :</label>
        <textarea
          id="message"
          name="message"
          placeholder="Entrez votre message"
          required
          :aria-describedby="messageError ? 'message-error' : null"
          aria-invalid="messageError ? 'true' : 'false'"
        ></textarea>
        <span v-if="messageError" id="message-error" role="alert" class="error-message">
          {{ messageError }}
        </span>
      </fieldset>
      <button type="submit">Envoyer</button>
    </form>
  </section>
</template>
</style>
```
