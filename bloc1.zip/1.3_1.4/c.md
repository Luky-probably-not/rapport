# Activités 1.3 et 1.4 : Programmation de briques et services logiciels, conception de services métiers et conception de services d'accès aux données

J'ai acquis ces compétences lors de la conception et du développement de l'API **ITeralis**, une plateforme communautaire permettant la consultation et le partage de cours de cybersécurité.

Afin de produire une application maintenable et évolutive, j'ai conçu une architecture organisée en plusieurs projets .NET distincts :

- `ITeralis.Application`
- `ITeralis.Abstractions`
- `ITeralis.Domain`
- `ITeralis.Repository`
- `ITeralis.Utilitaires`

Cette organisation permet de séparer les responsabilités entre la logique métier, l'accès aux données et les composants techniques transverses.

L'application a également été conçue suivant une architecture modulaire. Chaque domaine fonctionnel (Cours, Matières, Catégories, Utilisateurs ou Images) est organisé selon la même structure et dispose de ses propres endpoints, DTOs et composants de mapping.

Cette approche m'a permis de développer des briques logicielles réutilisables et homogènes. Lors de l'ajout de nouvelles fonctionnalités, comme la gestion des catégories ou des images, il a ainsi été possible de s'appuyer sur les modèles déjà existants plutôt que de redévelopper une architecture spécifique pour chaque besoin.

Les règles métier sont encapsulées dans des services logiciels exposés au travers d'interfaces définies dans le projet `ITeralis.Abstractions`.

Par exemple :

```text
Endpoint
        ↓

ICoursRepository

        ↓

CoursRepository

        ↓

Entity Framework Core

        ↓

MariaDB
```

Les endpoints ne contiennent aucune logique de persistance et ne dépendent que des interfaces métier. Cette approche applique le principe d'inversion des dépendances et limite le couplage entre les différentes couches de l'application.

Afin d'assurer l'indépendance de l'accès aux données vis-à-vis du mode de stockage utilisé, j'ai mis en œuvre le pattern Repository associé à **Entity Framework Core** et à une base de données **MariaDB**.

Chaque domaine fonctionnel possède son propre contrat :

- `ICoursRepository`
- `IUtilisateurRepository`
- `IMatiereRepository`
- `ICategorieRepository`
- `IImageRepository`

Ces interfaces sont définies dans `ITeralis.Abstractions` tandis que leurs implémentations sont réalisées dans `ITeralis.Repository`.

Cette organisation permet aux couches métier de manipuler exclusivement des contrats sans dépendre directement de la technologie de stockage. Si le moteur de base de données devait évoluer, seule la couche Repository devrait être adaptée, sans impact sur les couches supérieures.

J'ai également pris en compte la sécurité et l'intégrité des données à plusieurs niveaux.

Au niveau applicatif :

- validation des données avant écriture ;
- contrôle des incohérences ;
- exceptions métier dédiées pour chaque domaine.

Au niveau de la base de données :

- clés primaires ;
- clés étrangères ;
- contraintes `NOT NULL` ;
- contraintes `UNIQUE` sur les champs sensibles tels que l'adresse électronique ou le nom d'utilisateur.

Enfin, l'ensemble des accès aux données repose sur Entity Framework Core et LINQ. Les requêtes SQL sont générées automatiquement par l'ORM et paramétrées par défaut, limitant les risques d'injection SQL.

Cette architecture m'a permis de produire des services métiers réutilisables et des services d'accès aux données indépendants du mode de stockage, tout en garantissant la cohérence, la sécurité et la maintenabilité de l'application.
