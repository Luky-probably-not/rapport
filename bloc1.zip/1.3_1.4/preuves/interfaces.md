# Interfaces et implémentations

## ICoursRepository

```csharp
public interface ICoursRepository
{
    Task<IEnumerable<Cours>> FindAll();

    Task<Cours> Insert(Cours cours);

    Task<IEnumerable<Cours>> RecupererLesCoursMatieres(Guid idMatiere);

    Task<Cours> RecupererUnCours(Guid idCours);

    Task<Cours> ModifierUnCours(Guid idCours, Cours cours);
}
```

## Implémentation

```csharp
public class CoursRepository(CoursDbContext dbContext) : ICoursRepository
{
    public async Task<IEnumerable<Cours>> FindAll()
    {
        return await dbContext.Cours.ToListAsync();
    }

    public async Task<Cours> Insert(Cours cours)
    {
        dbContext.Add(cours);
        await dbContext.SaveChangesAsync();
        return cours;
    }
}
```
