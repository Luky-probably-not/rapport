public class ExceptionMiddleware(IProblemDetailsService problemDetailsService, IHostEnvironment environment) : IExceptionHandler
{
    public async ValueTask<bool> TryHandleAsync(HttpContext httpContext, Exception exception, CancellationToken cancellationToken)
    {
        var (status, type) = exception switch
        {
            ValidationException => (StatusCodes.Status400BadRequest, ErreurType.Validation),
            NotFoundException => (StatusCodes.Status404NotFound, ErreurType.NonTrouve),

            _ => (StatusCodes.Status500InternalServerError, ErreurType.ErreurInterne)
        };

        httpContext.Response.StatusCode = status;

        var problemDetails = new ProblemDetails
        {
            Type = Enum.GetName(type),
            Title = exception.GetType().Name
        };

        problemDetails.Detail = exception.Message;
        if (exception is BaseException baseException)
        {
            problemDetails.Extensions.Add("ErrorCode", baseException.ErreurCode);
            problemDetails.Extensions.Add("Instance", $"{httpContext.Request.Method} {httpContext.Request.Path.Value}");
        }
            

        return await problemDetailsService.TryWriteAsync(new ProblemDetailsContext()
        {
            HttpContext = httpContext,
            Exception = exception,
            ProblemDetails = problemDetails
        });
    }
}