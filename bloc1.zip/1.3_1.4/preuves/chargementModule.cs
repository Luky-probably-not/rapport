public static class IEndpointRouteBuilderExtensions
{
    public static IEndpointRouteBuilder AddModule(this IEndpointRouteBuilder builder, string path, string module)
    {
        var type = typeof(IEndpointBuilder);
        var types = AppDomain.CurrentDomain.GetAssemblies()
            .SelectMany(s => s.GetTypes())
            .Where(p => type.IsAssignableFrom(p)
                        && p is { IsInterface: false, IsAbstract: false }
                        && p.Namespace!.Contains(module));

        foreach (var t in types)
        {
            var endpoint = (IEndpointBuilder)Activator.CreateInstance(t)!;
            endpoint.AddEndpoint(builder, path, module);
        }

        return builder;
    }

    public static IEndpointRouteBuilder LoadModules(this IEndpointRouteBuilder builder, string basePath)
    {
        var type = typeof(ILoader);
        var types = AppDomain.CurrentDomain.GetAssemblies()
            .SelectMany(s => s.GetTypes())
            .Where(p => type.IsAssignableFrom(p)
                        && p is { IsInterface: false, IsAbstract: false })
            .ToList();

        types.ForEach(t =>
        {
            var module = (ILoader)Activator.CreateInstance(t)!;
            module.LoadModule(builder, basePath);
        });

        return builder;
    }
}