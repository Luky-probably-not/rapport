# Tests

## Traitement sans erreur

```csharp
[Fact]
public async Task CatchErrorBuilder_ProcessRealiseSansException()
{
    var result = await new CatchErrorBuilder(Mock.Of<ILogger<CatchErrorBuilder>>())
        .DefinirTraitement(Traitement)
        .Executer();

    var httpStatusCode = result as Http.IStatusCodeHttpResult;
    Assert.NotNull(httpStatusCode);
    Assert.Equal(Http.StatusCodes.Status200OK, httpStatusCode.StatusCode);
    return;

    static Task<Http.IResult> Traitement() => Task.FromResult(Http.Results.Ok());
}
```

## Traitement générant une exception locale

```csharp
[Fact]
public async Task CatchErrorBuilder_ExceptionNonGere_Validation()
{
    //Arrange
    var ex = new TestValidationException();

    //Act
    var result = await new CatchErrorBuilder(Mock.Of<ILogger<CatchErrorBuilder>>())
        .DefinirTraitement(() => throw ex)
        .Executer();

    //Assert
    var httpResult = Assert.IsType<Http.HttpResults.BadRequest<ProblemDetails>>(result);

    var problemDetails = httpResult.Value;

    var expectedProblemDetails = new ProblemDetails
    {
        Status = (int)HttpStatusCode.BadRequest,
        Title = nameof(TestValidationException),
        Type = Enum.GetName(ErreurType.Validation),
        Extensions = new Dictionary<string, object?>()
        {
            { "ErrorCode", ex.ErrorCode },
            { "IsTechnical", false }
        },
        Detail = ex.Message
    };

    Assert.Equivalent(expectedProblemDetails, problemDetails);
}
```

## Traitement provoquant une erreur lors d'un appel à une API externe

```csharp
[Fact]
public async Task CatchErrorBuilder_OnClientExceptionError_ProcessAvecClientException()
{
    var err = new Erreur
    {
        Detail = "detail",
        ErrorCode = "error_code",
        IsTechnical = true,
        Title = "title",
        Type = ErreurType.Validation
    };

    var ex = new ClientException(err);

    var result = await new CatchErrorBuilder(Mock.Of<ILogger<CatchErrorBuilder>>())
        .DefinirTraitement(() => throw ex)
        .OnValidation(_ => Http.Results.Problem(statusCode:79))
        .Executer();

    var httpStatusCode = result as Http.IStatusCodeHttpResult;

    Assert.NotNull(httpStatusCode);
    Assert.Equal(79, httpStatusCode.StatusCode);
}
```

## Traitement avec une erreur explicitement prévue

```csharp
[Fact]
public async Task CatchErrorBuilder_OnValidationError_ProcessAvecValidationException()
{
    var ex = new TestValidationException();

    var result = await new CatchErrorBuilder(Mock.Of<ILogger<CatchErrorBuilder>>())
        .DefinirTraitement(() => throw ex)
        .OnValidation(_ => Http.Results.Problem(statusCode:40))
        .Executer();

    var httpStatusCode = result as Http.IStatusCodeHttpResult;

    Assert.NotNull(httpStatusCode);

    Assert.Equal(40, httpStatusCode.StatusCode);
}
```

## Exécution du builder sans définition préalable du traitement à exécuter

```csharp
[Fact]
public async Task CatchErrorBuilder_ProcessNull_NonRecuperable()
{
    var task = new CatchErrorBuilder(Mock.Of<ILogger<CatchErrorBuilder>>())
        .OnNonRecuperable(_ => Http.Results.Problem(statusCode: 23));

    await Assert.ThrowsAsync<TraitementNullException>(() => task.Executer());
}
```
